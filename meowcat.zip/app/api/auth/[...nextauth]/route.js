// app/api/auth/[...nextauth]/route.ts
import { handlers } from "@/auth"; // 引用刚才创建的 auth.ts

export const { GET, POST } = handlers;
